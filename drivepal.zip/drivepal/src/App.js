import './App.css';
import { LoginSignUp } from './Components/LoginSignUp/LoginSignUp';
function App() {
  return (
    <div>
      <LoginSignUp></LoginSignUp>
    </div>
  );
}
export default App;
